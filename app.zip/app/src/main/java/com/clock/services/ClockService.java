package com.clock.services;

import org.springframework.stereotype.Service;

import com.clock.utils.ClockConstants;

@Service
public class ClockService {
	
	
	public String convertTimeToWords(String time) {
		
		String result ="its ";
		String meridian ="";
		
		String[] temp = time.split(":");
		int hours = Integer.parseInt(temp[0]);
		int mins = Integer.parseInt(temp[1]);
		
		if(hours > 0 && hours < 12) {
			result += ClockConstants.timeInWords[hours] + " hours " ;
			meridian = "AM";
		} 
		
		if(hours == 0) {
			
			result += " Mid Night ";
		}
		if(hours == 12) {
			
			result += " Mid Day ";
		}
		
		if(hours > 12 && hours <= 23) {
			
			result += ClockConstants.timeInWords[hours-12] + " hours ";
			meridian = "PM";
		}		
		
		if (mins > 0 && mins <= 59) {		
				
				result += ClockConstants.timeMinsInWords[mins] + " minutes ";
			}
			
			result += meridian;
		
		return result;
	}

}
