package com.clock.exception;

public class TimeConversionException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

	
}
