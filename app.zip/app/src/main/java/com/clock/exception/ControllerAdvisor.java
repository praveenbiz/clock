package com.clock.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ControllerAdvisor extends ResponseEntityExceptionHandler{
	
	
	@ExceptionHandler({TimeConversionException.class})
	public ResponseEntity<Object> handleResponseEntity(TimeConversionException ex, String message) {
		
				logger.error("Time Conversion Exception");		        
		        return handleResponseEntity(ex, "Time Conversion Exception");
		    }
	
	@Override
	public ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
	    String name = ex.getParameterName();
	    logger.error(name + " parameter is missing");	    
	    return super.handleMissingServletRequestParameter(ex, headers, status, request);
	}

}
