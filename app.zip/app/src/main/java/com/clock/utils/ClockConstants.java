package com.clock.utils;

public class ClockConstants {
	
	
	public static String timeInWords[]= new String[] {
			
			"zero","one","two","three", "four", "five", "six", "seven", "eight", "nine","ten",
			"eleven","twelve"
			
	};
	
public static String timeMinsInWords[]= new String[] {
			
			"zero","one","two","three", "four", "five", "six", "seven", "eight", "nine","ten",
			"eleven","twelve", "therteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen","ninteen",
			"twenty","twenty one","twenty two", "twenty three", "twenty four", "twenty five", "twenty six", "twenty seven", "twenty eight","twenty nine",
			"therty","therty one","therty two", "therty three", "therty four", "therty five", "therty six", "therty seven", "therty eight","therty nine",
			"fourty","fourty one","fourty two", "fourty three", "fourty four", "fourty five", "fourty six", "fourty seven", "fourty eight","fourty nine",
			"fifty","fifty one","fifty two", "fifty three", "fifty four", "fifty five", "fifty six", "fifty seven", "fifty eight","fifty nine"
			
	};

}
