package com.clock.app;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.clock.services.ClockService;

@SpringBootTest
class AppApplicationTests {
	
	@Autowired
	ClockService clockService;

	@Test
	void testTime() {
		
		String value = clockService.convertTimeToWords("11:30");
		System.out.println("value = "+value);
		Assertions.assertEquals("its eleven hours therty minutes AM", value);

	}

}
