This application is converting time in numbers to words as output.
using java, springboot, swagger for api documentation.

To run application

1. import the application as maven project to any IDE like eclipse.
2. After importing Run mvn clean install command.
3. then run java -jar app.jar.
4. finaly check browser with default port localhost:8080/api/, where application is hosted.


